/* ===== Состояние интерфейса ===== */
const UI = {
  app: 'client', view: 'menu', goal: 'all', type: 'all', q: '', sort: 'pop',
  cart: {}, drawer: null, modal: null, lastOrder: null, payErr: '',
  co: { mode: 'gym', when: 'asap', time: '', name: '', phone: '', card: '', comment: '', pay: 'card', num: '2200 1234 5678 9010', exp: '12/28', cvc: '123' },
  sub: 'all', kSt: 'all', wTab: 'up', lockMsg: null, lockIn: '', cafeNo: '',
  mq: '', mGoal: 'all', mType: 'all', sq: '', sCat: 'all', sStatus: 'all', pAll: false, pChoice: {}, editDish: null, mView: 'admin-menu',
};
const ICON = {
  logo: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M3 6h5v4.5h5V15h5v4" stroke="#c9f26b" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M15.5 17.5 18 20l2.5-2.5" stroke="#c9f26b" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  cart: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 7h12l-1 13H7L6 7Z"/><path d="M9 7a3 3 0 0 1 6 0"/></svg>',
  search: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
  stairs: '<svg width="260" height="200" viewBox="0 0 260 200" fill="none"><path d="M0 40h70v50h60v50h60v50h70" stroke="#c9f26b" stroke-width="18"/></svg>',
};

/* ===== Корзина ===== */
const cartCount = () => Object.values(UI.cart).reduce((s, q) => s + q, 0);
const cartSum = () => Object.entries(UI.cart).reduce((s, [id, q]) => s + (DISH[id] ? effPrice(DISH[id]) * q : 0), 0);
const cartFull = () => Object.entries(UI.cart).reduce((s, [id, q]) => s + (DISH[id] ? DISH[id].price * q : 0), 0);
function canAddMore(d) { return !d.stop && portions(d, needFor(UI.cart)) >= 1; }
function cartAdd(id, n = 1) {
  const d = DISH[id]; if (!d) return;
  if (n > 0 && !canAddMore(d)) { toast('Больше нет в наличии: ' + d.name, 'warn'); return; }
  const q = (UI.cart[id] || 0) + n; if (q <= 0) delete UI.cart[id]; else UI.cart[id] = q; render();
}
function myOrders() { const ids = new Set(myOrderIds()); return Object.values(S.orders).filter(o => ids.has(o.id)).sort((a, b) => b.createdAt - a.createdAt); }
const myActive = () => myOrders().filter(o => o.status !== 'done' && o.status !== 'cancelled');

function filteredDishes() {
  const q = UI.q.trim().toLowerCase();
  let list = S.catalog.dishes.filter(d => (UI.goal === 'all' || d.goals.includes(UI.goal)) && (UI.type === 'all' || d.type === UI.type) && (UI.type !== 'drink' || UI.sub === 'all' || d.sub === UI.sub) && (!q || (d.name + ' ' + d.desc).toLowerCase().includes(q)));
  const sorters = { pop: (a, b) => (b.hit - a.hit) || (b.pop - a.pop), priceAsc: (a, b) => effPrice(a) - effPrice(b), priceDesc: (a, b) => effPrice(b) - effPrice(a), kcalAsc: (a, b) => a.kcal - b.kcal, protein: (a, b) => b.p - a.p };
  list.sort(sorters[UI.sort] || sorters.pop);
  list.sort((a, b) => (onSale(b) ? 1 : 0) - (onSale(a) ? 1 : 0));
  return list;
}
function drinkGroups(ds) {
  let h = ''; const rest = ds.filter(d => !d.sub);
  DRINK_SUBS.forEach(s => { const g = ds.filter(d => d.sub === s.id); if (g.length) h += `<div class="sub-h"><h3>${s.name}</h3><span class="muted small">${g.length}</span></div><div class="grid">${g.map(dishCard).join('')}</div>`; });
  if (rest.length) h += `<div class="sub-h"><h3>Другие напитки</h3></div><div class="grid">${rest.map(dishCard).join('')}</div>`;
  return h;
}
const goalColor = d => (GOAL[d.goals[0]] || { color: '#8a9a90' }).color;
function dishCard(d) {
  const left = portions(d), inCart = UI.cart[d.id] || 0, sold = (d.stop || left === 0) && !inCart, price = effPrice(d);
  const btn = inCart
    ? `<div class="stepper"><button data-act="minus" data-id="${d.id}" aria-label="Убрать">−</button><span>${inCart}</span><button data-act="plus" data-id="${d.id}" ${canAddMore(d) ? '' : 'disabled'} aria-label="Добавить">+</button></div>`
    : `<button class="add" data-act="plus" data-id="${d.id}" ${canAddMore(d) ? '' : 'disabled'} aria-label="В корзину">+</button>`;
  return `<article class="dish ${sold ? 'soldout' : ''}" data-act="dish" data-id="${d.id}" style="--gc:${goalColor(d)}">
    <div class="pic"><span class="em">${d.emoji}</span>
      <div class="badges">${d.hit ? '<span class="badge hit">ХИТ ДНЯ</span>' : ''}${d.discount ? `<span class="badge sale">−${d.discount}%</span>` : ''}${sold ? '<span class="badge out">Закончилось</span>' : ''}${d.station === 'bar' ? `<span class="badge">${d.sub === 'water' ? '🧴 бутылка' : '🥤 стакан'}</span>` : ''}</div>
      <span class="kcal">${d.kcal} ккал</span></div>
    <div class="body"><div class="nm">${esc(d.name)}</div>
      <div class="meta">${esc(d.weight)}${d.serves > 1 ? ' · на ' + d.serves + ' перс.' : ''} · ${d.cook} мин</div>
      <div class="macros"><span><b>Б</b>${d.p}</span><span><b>Ж</b>${d.f}</span><span><b>У</b>${d.c}</span></div>
      <div class="foot"><div><div class="price">${fmtRub(price)}</div>${d.discount ? `<div class="old">${fmtRub(d.price)}</div>` : ''}${!sold && left <= 5 ? `<div class="left">Осталось ${left}</div>` : ''}</div>${btn}</div>
    </div></article>`;
}

/* ===== Сайт клиента ===== */
function clientHead() {
  const cnt = cartCount(), act = myActive().length;
  return `<header class="site-head"><div class="in">
    <a class="logo" href="#menu" data-act="home"><span class="mark">${ICON.logo}</span><div><div class="t1">Этажом ниже</div><div class="t2">кухня для тех, кто тренируется этажом выше</div></div></a>
    <div class="spacer"></div>
    <button class="btn ${act ? '' : 'ghost hide-m'}" data-act="my-orders">${act ? 'Заказы' : 'Мои заказы'}${act ? ` <span class="cnt">${act}</span>` : ''}</button>
    <button class="btn primary" data-act="open-cart">${ICON.cart}<span class="${cnt ? '' : 'cart-lbl'}">${cnt ? fmtRub(cartSum()) : 'Корзина'}</span>${cnt ? `<span class="cnt">${cnt}</span>` : ''}</button>
  </div></header>`;
}
function clientMain() {
  const typical = minReadyAt({ chickenrice: 1 }, 'gym');
  const filtered = UI.goal !== 'all' || UI.type !== 'all' || UI.q.trim();
  const list = filteredDishes();
  const hits = S.catalog.dishes.filter(d => d.hit && !d.stop), sales = S.catalog.dishes.filter(d => d.discount > 0 && !d.stop);
  const goalBtn = g => `<button class="goal ${UI.goal === g.id ? 'on' : ''}" style="--gc:${g.color}" data-act="goal" data-id="${g.id}"><span class="ic">${g.icon}</span><span class="nm">${g.name}</span><span class="hn">${g.hint}</span></button>`;
  let body = '';
  if (!filtered) {
    body += `<div class="sec-h"><h2>Хиты дня</h2><span class="muted">выбор шефа на сегодня</span></div><div class="rail">${hits.map(dishCard).join('') || '<div class="empty">Сегодня без хитов</div>'}</div>`;
    if (sales.length) body += `<div class="sec-h"><h2>Скидки сегодня</h2><span class="muted">цена уже со скидкой</span></div><div class="rail">${sales.map(dishCard).join('')}</div>`;
    TYPES.forEach(t => { const ds = list.filter(d => d.type === t.id); if (!ds.length) return; body += `<div class="sec-h"><h2>${t.name}</h2><span class="muted">${ds.length} ${plural(ds.length, 'позиция', 'позиции', 'позиций')}</span></div>`; body += t.id === 'drink' ? drinkGroups(ds) : `<div class="grid">${ds.map(dishCard).join('')}</div>`; });
  } else {
    const g = GOAL[UI.goal];
    const subName = UI.type === 'drink' && UI.sub !== 'all' ? (DRINK_SUBS.find(s => s.id === UI.sub) || {}).name : null;
    body += `<div class="sec-h"><h2>${g ? g.icon + ' ' + g.name : subName || (UI.type !== 'all' ? TYPE[UI.type].name : 'Результаты поиска')}</h2><span class="muted">${list.length} ${plural(list.length, 'позиция', 'позиции', 'позиций')}${g ? ' · ' + g.hint : ''}</span><span class="spacer"></span><button class="btn sm ghost" data-act="reset-filters">Сбросить фильтры</button></div>`;
    body += list.length ? (UI.type === 'drink' && UI.sub === 'all' && !UI.q.trim() ? drinkGroups(list) : `<div class="grid">${list.map(dishCard).join('')}</div>`) : '<div class="empty">Ничего не нашлось. Попробуйте другую цель или тип блюда.</div>';
  }
  return `<div class="wrap">
    <section class="hero">
      <div class="main"><div class="stairs">${ICON.stairs}</div>
        <h1>Тренируйтесь — <em>мы приготовим</em> к вашему выходу из зала</h1>
        <p>Закажите из кафе этажом ниже и укажите, к какому времени. Еду положим в ячейку шкафа наверху — откроете своим QR-кодом, напиток будет ждать на стойке ресепшена с номером заказа.</p>
        <div class="steps"><div class="s"><b>1</b>Выберите блюда под цель</div><div class="s"><b>2</b>Укажите время</div><div class="s"><b>3</b>Заберите по QR из ячейки</div></div>
        <div class="m-only small" style="margin-top:14px;color:#d6e8dc">Ближайшая готовность — <b style="color:#fff">${typical ? fmtTime(typical) : '—'}</b> · кухня 07:30–22:30</div>
      </div>
      <div class="side">
        <div class="muted small">Ближайшая готовность наверху</div>
        <div class="big">${typical ? fmtTime(typical) : '—'}</div>
        <div class="tiny muted" style="margin-top:-8px">считаем по текущей загрузке кухни</div>
        <div class="kv"><span class="muted">Где забрать</span><b>ячейка шкафа · стойка · кафе</b></div>
        <div class="kv"><span class="muted">Оплата</span><b>онлайн: карта или СБП</b></div>
        <div class="kv"><span class="muted">Сейчас в меню</span><b>${S.catalog.dishes.filter(onSale).length} из ${S.catalog.dishes.length} блюд</b></div>
        <span class="spacer"></span>
        <button class="btn lime lg" style="justify-content:center" data-act="to-menu">Выбрать блюда под цель ↓</button>
      </div>
    </section>
    <div class="goals"><button class="goal ${UI.goal === 'all' ? 'on' : ''}" data-act="goal" data-id="all"><span class="ic">🍽️</span><span class="nm">Всё меню</span><span class="hn">${S.catalog.dishes.length} позиций</span></button>${GOALS.map(goalBtn).join('')}</div>
    <div class="toolbar"><div class="tabs"><button class="tab ${UI.type === 'all' ? 'on' : ''}" data-act="type" data-id="all">Все</button>${TYPES.map(t => `<button class="tab ${UI.type === t.id ? 'on' : ''}" data-act="type" data-id="${t.id}">${t.name}</button>`).join('')}</div></div>
    ${UI.type === 'drink' ? `<div class="toolbar"><div class="tabs subtabs"><button class="tab ${UI.sub === 'all' ? 'on' : ''}" data-act="sub" data-id="all">Все напитки</button>${DRINK_SUBS.map(s => `<button class="tab ${UI.sub === s.id ? 'on' : ''}" data-act="sub" data-id="${s.id}">${s.name}</button>`).join('')}</div></div>` : ''}
    <div class="toolbar">
      <div class="search">${ICON.search}<input class="input" data-f="q" data-fk="q" placeholder="Поиск: лосось, творог, без мяса…" value="${esc(UI.q)}"></div>
      <select class="input" data-f="sort">${[['pop', 'Сначала популярные'], ['priceAsc', 'Сначала дешевле'], ['priceDesc', 'Сначала дороже'], ['kcalAsc', 'Меньше калорий'], ['protein', 'Больше белка']].map(([v, n]) => `<option value="${v}" ${UI.sort === v ? 'selected' : ''}>${n}</option>`).join('')}</select>
    </div>
    ${body}
  </div>
  <footer class="f"><span>«Этажом ниже» — прототип сервиса заказа еды для фитнес-клуба.</span><span>Оплата в прототипе — имитация, деньги не списываются.</span></footer>
  ${orderPill()}`;
}
function orderPill() {
  const a = myActive(); if (!a.length || UI.drawer || UI.modal) return '';
  const o = a[0];
  return `<button class="orderpill" data-act="track" data-id="${o.id}">Заказ №${o.no} · к ${fmtTime(o.readyAt)} <span class="st">${clientStatus(o)}</span></button>`;
}
function clientStatus(o) {
  if (o.status === 'placed') return o.mode === 'cafe' ? 'На стойке кафе' : (o.bag.need ? 'В ячейке ' + o.bag.cell : 'На стойке');
  if (o.status === 'ready') return o.mode === 'cafe' ? 'Готов' : 'Готов, несём';
  return STATUS[o.status].short;
}

function dishModal(d) {
  const left = portions(d), inCart = UI.cart[d.id] || 0;
  const ings = d.recipe.map(x => ING[x.ing] ? ING[x.ing].name.replace(/\s*\(.*\)/, '').toLowerCase() : '').filter(Boolean);
  return `<div class="overlay" data-act="close-modal"><div class="modal">
    <div class="mh"><h3>${esc(d.name)}</h3><button class="x" data-act="close-modal">×</button></div>
    <div class="mb"><div class="dm-top"><div class="dm-pic" style="--gc:${goalColor(d)}">${d.emoji}</div><div>
      <div class="goal-dots">${d.goals.map(g => `<span class="gdot" style="--gc:${GOAL[g].color}">${GOAL[g].name}</span>`).join('')}${d.hit ? '<span class="badge hit">ХИТ ДНЯ</span>' : ''}${d.discount ? `<span class="badge sale">−${d.discount}%</span>` : ''}</div>
      <p>${esc(d.desc)}</p>
      <div class="kbju"><div><b>${d.kcal}</b><span>ккал</span></div><div><b>${d.p} г</b><span>белки</span></div><div><b>${d.f} г</b><span>жиры</span></div><div><b>${d.c} г</b><span>углеводы</span></div></div>
      <div class="small muted">Выход ${esc(d.weight)}${d.serves > 1 ? ' · на ' + d.serves + ' персоны, КБЖУ на 1 порцию' : ''} · ${STATION[d.station].name.toLowerCase()}, ${d.cook} мин${d.station === 'bar' ? ' · подаём в стакане с номером заказа' : ''}</div>
      <div class="small" style="margin-top:8px"><b>Состав:</b> ${esc(ings.join(', '))}</div>
      <div class="row" style="margin-top:16px"><div><div class="price">${fmtRub(effPrice(d))}</div>${d.discount ? `<div class="old">${fmtRub(d.price)}</div>` : ''}</div><span class="spacer"></span>
        ${d.stop || left === 0 ? '<span class="st out">Закончилось</span>' : (left <= 5 ? `<span class="left">Осталось ${left}</span>` : '')}
        ${inCart ? `<div class="stepper"><button data-act="minus" data-id="${d.id}">−</button><span>${inCart}</span><button data-act="plus" data-id="${d.id}" ${canAddMore(d) ? '' : 'disabled'}>+</button></div>` : `<button class="btn primary" data-act="plus" data-id="${d.id}" ${canAddMore(d) ? '' : 'disabled'}>В корзину</button>`}
      </div></div></div></div></div></div>`;
}

/* ===== Оформление: место, время, оплата ===== */
function coTimes() {
  const min = minReadyAt(UI.cart, UI.co.mode); if (!min) return null;
  let t;
  if (UI.co.when === 'asap') t = min;
  else if (UI.co.when === 'custom') { if (UI.co.time) { const [h, m] = UI.co.time.split(':').map(Number); const d = new Date(); d.setHours(h, m, 0, 0); if (d.getTime() < Date.now() - 6 * 3600e3) d.setDate(d.getDate() + 1); t = d.getTime(); } else t = min; }
  else { const d = new Date(Date.now() + UI.co.when * MIN); d.setMinutes(Math.ceil(d.getMinutes() / 5) * 5, 0, 0); t = d.getTime(); }
  const bumped = t < min; t = Math.max(t, min);
  const fake = buildOrder(S.catalog, Object.entries(UI.cart).map(([id, q]) => [id, q]), { mode: UI.co.mode });
  const start = t - deliverMs(fake) - packMs(fake) - Math.max(...fake.tasks.map(x => x.dur));
  return { min, t, bumped, start, fake };
}
function cartDrawer() {
  const ids = Object.keys(UI.cart);
  const head = t => `<div class="dh">${['checkout', 'pay'].includes(UI.drawer) ? '<button class="x" data-act="co-back">‹</button>' : ''}<h3>${t}</h3><button class="x" data-act="close-drawer">×</button></div>`;
  let h = '';
  if (UI.drawer === 'cart') {
    const saved = cartFull() - cartSum(), min = minReadyAt(UI.cart, UI.co.mode);
    h = head('Корзина') + `<div class="db">${ids.length ? ids.map(id => { const d = DISH[id]; if (!d) return ''; return `<div class="ci"><div class="e">${d.emoji}</div><div class="n">${esc(d.name)}<div class="tiny muted">${fmtRub(effPrice(d))} · ${d.kcal} ккал${d.station === 'bar' ? ' · в стакане' : ''}</div></div><div class="stepper"><button data-act="minus" data-id="${id}">−</button><span>${UI.cart[id]}</span><button data-act="plus" data-id="${id}" ${canAddMore(d) ? '' : 'disabled'}>+</button></div></div>`; }).join('') : '<div class="empty">Корзина пуста. Выберите блюда под свою цель.</div>'}
      ${ids.length ? `<div class="note green" style="margin-top:12px">Минимальное время готовности: <b>${fmtTime(min)}</b>. Считаем по загрузке кухни прямо сейчас.</div>
      <div style="margin-top:10px">${saved > 0 ? `<div class="sum-row"><span class="muted">Скидка</span><span>−${fmtRub(saved)}</span></div>` : ''}
      <div class="sum-row"><span class="muted">Итого КБЖУ</span><span class="small">${ids.reduce((s, id) => s + DISH[id].kcal * UI.cart[id], 0)} ккал · Б ${ids.reduce((s, id) => s + DISH[id].p * UI.cart[id], 0)} г</span></div>
      <div class="sum-row total"><span>К оплате</span><span>${fmtRub(cartSum())}</span></div></div>` : ''}</div>
      <div class="df"><button class="btn primary lg" style="width:100%;justify-content:center" data-act="co-next" ${ids.length ? '' : 'disabled'}>Оформить заказ</button></div>`;
  } else if (UI.drawer === 'checkout') {
    const tm = coTimes(); if (!tm) { UI.drawer = 'cart'; return cartDrawer(); }
    const hasDrink = tm.fake.cup.need, hasFood = tm.fake.bag.need;
    const gymText = hasFood && hasDrink ? 'Еда — в ячейке шкафа (откроете QR-кодом), напиток — на стойке ресепшена с номером заказа' : hasFood ? 'Пакет положим в ячейку шкафа, откроете своим QR-кодом' : 'Напиток с номером заказа поставим на стойку ресепшена';
    h = head('Оформление') + `<div class="db">
      <div class="field"><label>Где заберёте?</label><div class="paym">
        <button class="${UI.co.mode === 'gym' ? 'on' : ''}" data-act="co-mode" data-v="gym">🏋️ Наверху, в клубе<small>${gymText}</small></button>
        <button class="${UI.co.mode === 'cafe' ? 'on' : ''}" data-act="co-mode" data-v="cafe">☕ В кафе<small>Заберу сам на стойке выдачи кафе</small></button></div></div>
      <div class="field"><label>К какому времени приготовить и ${UI.co.mode === 'cafe' ? 'выдать' : 'принести'}?</label>
        <div class="minbox"><span>Минимальное время</span><b>${fmtTime(tm.min)}</b><span class="tiny muted">обновляется по загрузке кухни</span></div>
        <div class="chips" style="margin-top:8px">
          <button class="chip ${UI.co.when === 'asap' ? 'on' : ''}" data-act="co-when" data-v="asap">Как можно скорее</button>
          ${[30, 45, 60, 90].map(m => `<button class="chip ${UI.co.when === m ? 'on' : ''}" data-act="co-when" data-v="${m}">через ${m} мин</button>`).join('')}
          <button class="chip ${UI.co.when === 'custom' ? 'on' : ''}" data-act="co-when" data-v="custom">Своё время</button></div>
        ${UI.co.when === 'custom' ? `<input class="input" type="time" data-co="time" data-fk="co-time" value="${esc(UI.co.time)}" min="${fmtTime(tm.min)}" style="margin-top:8px;width:140px">` : ''}
      </div>
      <div class="note green">Заказ будет ${UI.co.mode === 'cafe' ? 'на стойке кафе' : 'наверху'} к <b>${fmtTime(tm.t)}</b>. Кухня начнёт готовить около ${fmtTime(tm.start)} — вы в это время тренируетесь.${tm.bumped ? ` Раньше ${fmtTime(tm.min)} не успеем — время сдвинуто.` : ''}</div>
      <div style="height:12px"></div>
      <div class="field"><label>Имя *</label><input class="input" data-co="name" data-fk="co-name" value="${esc(UI.co.name)}" placeholder="Как к вам обращаться"></div>
      <div class="field"><label>Телефон *</label><input class="input" data-co="phone" data-fk="co-phone" value="${esc(UI.co.phone)}" placeholder="+7 900 000-00-00" inputmode="tel"></div>
      <div class="field"><label>Номер клубной карты</label><input class="input" data-co="card" data-fk="co-card" value="${esc(UI.co.card)}" placeholder="необязательно"></div>
      <div class="field"><label>Комментарий для кухни</label><input class="input" data-co="comment" data-fk="co-comment" value="${esc(UI.co.comment)}" placeholder="Например: без лука, соус отдельно"></div>
      ${UI.payErr ? `<div class="note red">${esc(UI.payErr)}</div>` : ''}</div>
    <div class="df"><div class="sum-row total" style="padding:0 0 10px"><span>К оплате</span><span>${fmtRub(cartSum())}</span></div><button class="btn primary lg" style="width:100%;justify-content:center" data-act="co-topay">Перейти к оплате</button></div>`;
  } else if (UI.drawer === 'pay') {
    h = head('Оплата') + `<div class="db">
      <div class="paym"><button class="${UI.co.pay === 'card' ? 'on' : ''}" data-act="co-pay" data-v="card">💳 Картой<small>Мир, Visa, Mastercard</small></button><button class="${UI.co.pay === 'sbp' ? 'on' : ''}" data-act="co-pay" data-v="sbp">⚡ СБП<small>через приложение банка</small></button></div>
      <div style="height:14px"></div>
      ${UI.co.pay === 'card' ? `<div class="field"><label>Номер карты</label><input class="input" data-co="num" data-fk="co-num" value="${esc(UI.co.num)}" inputmode="numeric"></div>
        <div class="row"><div class="field" style="flex:1"><label>Срок</label><input class="input" data-co="exp" data-fk="co-exp" value="${esc(UI.co.exp)}"></div><div class="field" style="flex:1"><label>CVC</label><input class="input" data-co="cvc" data-fk="co-cvc" value="${esc(UI.co.cvc)}" inputmode="numeric"></div></div>`
        : `<div style="text-align:center">${qrSVG('https://qr.nspk.ru/DEMO' + cartSum(), 'qr')}<div class="small muted">Отсканируйте QR-код в приложении банка или нажмите кнопку ниже</div></div>`}
      <div class="note" style="margin-top:12px">Демо-режим: деньги не списываются, данные карты никуда не отправляются.</div></div>
    <div class="df"><button class="btn primary lg" style="width:100%;justify-content:center" data-act="co-paynow">${UI.co.pay === 'card' ? 'Оплатить ' : 'Я оплатил(а) '}${fmtRub(cartSum())}</button></div>`;
  } else if (UI.drawer === 'paying') {
    h = head('Оплата') + `<div class="db"><div class="spinner"></div><p style="text-align:center" class="muted">Проводим оплату…</p></div>`;
  } else if (UI.drawer === 'success') {
    const o = S.orders[UI.lastOrder];
    h = head('Заказ оплачен') + (o ? `<div class="db">${orderCardBody(o, true)}</div>
      <div class="df"><button class="btn primary lg" style="width:100%;justify-content:center" data-act="track" data-id="${o.id}">Следить за заказом</button></div>` : '<div class="db">…</div>');
  }
  return `<div class="overlay" data-act="close-drawer" style="justify-content:flex-end;padding:0"></div><aside class="drawer">${h}</aside>`;
}
function placeOrder() {
  const need = needFor(UI.cart);
  const short = Object.entries(need).filter(([ing, q]) => available(ing) < q - 1e-9);
  if (short.length) { const dishes = Object.keys(UI.cart).filter(id => DISH[id].recipe.some(x => short.some(([i]) => i === x.ing))); UI.drawer = 'cart'; render(); toast('Пока вы оформляли, закончилось: ' + dishes.map(id => DISH[id].name).join(', '), 'warn', 6000); return; }
  const tm = coTimes();
  const o = buildOrder(S.catalog, Object.entries(UI.cart), { no: newOrderNo(), name: UI.co.name.trim(), phone: UI.co.phone.trim(), card: UI.co.card.trim(), comment: UI.co.comment.trim(), mode: UI.co.mode, payMethod: UI.co.pay, readyAt: tm.t, minAt: tm.min });
  saveOrder(o); addMyOrder(o.id);
  UI.cart = {}; UI.lastOrder = o.id; UI.drawer = 'success'; render();
}

/* ===== Страница заказа ===== */
function orderCardBody(o, fresh) {
  const gym = o.mode === 'gym', inCell = o.bag.need && o.bag.depositedAt && !o.bag.pickedAt;
  const cell = o.bag.cell && S.lockers ? S.lockers.cells.find(c => c.id === o.bag.cell) : null;
  const open = cell && cell.state === 'open' && cell.orderId === o.id && cell.openFor === 'pickup';
  let where = '';
  if (gym && o.bag.need) where += `<div class="part"><div class="pi">📦</div><div><b>Пакет — ячейка шкафа наверху</b><div class="small muted">${o.bag.pickedAt ? 'Получен в ' + fmtTime(o.bag.pickedAt) : inCell ? `Лежит в ячейке <b>${o.bag.cell}</b>. Поднесите QR-код к табло шкафа.` : 'QR-код сработает, когда официант положит заказ в ячейку.'}</div></div></div>`;
  if (gym && o.cup.need) where += `<div class="part"><div class="pi">🥤</div><div><b>Напиток — стойка ресепшена</b><div class="small muted">${o.cup.placedAt ? 'Уже на стойке, на стакане номер №' + o.no : 'Официант поставит стакан с номером №' + o.no + ' на стойку.'}</div></div></div>`;
  if (!gym) where += `<div class="part"><div class="pi">☕</div><div><b>Стойка выдачи в кафе</b><div class="small muted">${o.shelfAt ? 'Готово! Назовите номер или покажите QR-код.' : 'Покажите номер или QR-код на стойке кафе.'}</div></div></div>`;
  const showQR = (gym && o.bag.need) || !gym;
  return `<div class="success">${fresh ? '<div class="ok">✓</div>' : ''}<div class="muted">Номер заказа — он будет на ${o.bag.need ? 'пакете' : ''}${o.bag.need && o.cup.need ? ' и ' : ''}${o.cup.need ? 'стакане' : ''}</div><div class="code">№${o.no}</div>
      <p>Будет ${gym ? 'наверху' : 'на стойке кафе'} к <b>${fmtTime(o.readyAt)}</b>${o.minAt ? ` <span class="muted small">(минимально было ${fmtTime(o.minAt)})</span>` : ''}</p></div>
    ${showQR && o.status !== 'cancelled' && !(o.bag.pickedAt || o.status === 'done') ? `<div class="qrbox ${gym && !inCell ? 'dim' : ''}">${qrSVG(o.pickTok, 'qr big')}<div class="small"><b>Ваш QR-код ${gym ? 'для ячейки' : 'для выдачи'}</b><div class="muted tiny">${o.pickTok}</div>${gym ? (inCell ? (open ? `<div class="note green" style="margin-top:8px">Ячейка ${o.bag.cell} открыта — заберите заказ и закройте дверцу.</div><button class="btn sm" style="margin-top:8px" data-act="lk-close" data-id="${o.bag.cell}">Закрыл(а) дверцу</button>` : `<button class="btn sm lime" style="margin-top:8px" data-act="client-scan" data-id="${o.id}">Поднести к табло шкафа (демо)</button>`) : '<div class="tiny muted" style="margin-top:6px">Станет активным, когда заказ будет в ячейке</div>') : ''}</div></div>` : ''}
    <div class="parts">${where}</div>
    ${o.items.map(it => `<div class="ci"><div class="e">${it.e}</div><div class="n">${esc(it.n)}${it.drink ? ' <span class="tiny muted">· стакан</span>' : ''}</div><b>× ${it.q}</b></div>`).join('')}
    <div class="sum-row total"><span>Оплачено ${o.payMethod === 'sbp' ? 'по СБП' : 'картой'}</span><span>${fmtRub(o.total)}</span></div>`;
}
function trackModal(o) {
  const steps = o.mode === 'cafe' ? [['paid', 'Принят'], ['cooking', 'Готовится'], ['ready', 'Готов'], ['placed', 'На стойке кафе'], ['done', 'Получен']]
    : [['paid', 'Принят'], ['cooking', 'Готовится'], ['ready', 'Готов'], ['delivering', 'Официант несёт наверх'], ['placed', o.bag.need ? 'В ячейке' + (o.bag.cell ? ' ' + o.bag.cell : '') : 'На стойке ресепшена'], ['done', 'Получен']];
  const order = steps.map(s => s[0]); let idx = order.indexOf(o.status); if (idx < 0) idx = 0;
  return `<div class="overlay" data-act="close-modal"><div class="modal" style="width:min(560px,100%)">
    <div class="mh"><h3>Заказ №${o.no}</h3><button class="x" data-act="close-modal">×</button></div>
    <div class="mb">${o.status === 'cancelled' ? '<div class="note red">Заказ отменён, деньги вернутся на карту в течение нескольких минут.</div>' : `<div class="track hz">${steps.map(([k, t], i) => `<div class="tstep ${i <= idx ? 'done' : ''} ${i === idx && k !== 'done' ? 'cur' : ''}"><div class="c">${i <= idx ? '✓' : i + 1}</div><div><div class="t">${t}</div><div class="w">${o.history && o.history[k] ? fmtTime(o.history[k]) : ''}</div></div></div>`).join('')}</div>`}
      ${orderCardBody(o, false)}</div>
    <div class="mf">${o.status === 'paid' && !o.tasks.some(t => t.start) ? `<button class="btn danger" data-act="cancel-order" data-id="${o.id}">Отменить заказ</button>` : ''}<span class="spacer"></span><button class="btn" data-act="close-modal">Закрыть</button></div>
  </div></div>`;
}
function myOrdersModal() {
  const list = myOrders();
  return `<div class="overlay" data-act="close-modal"><div class="modal" style="width:min(560px,100%)">
    <div class="mh"><h3>Мои заказы</h3><button class="x" data-act="close-modal">×</button></div>
    <div class="mb">${list.length ? list.map(o => `<div class="ci" data-act="track" data-id="${o.id}" style="cursor:pointer"><div class="e" style="font-size:14px;font-weight:800">№${o.no}</div><div class="n">${fmtRub(o.total)} · ${o.mode === 'cafe' ? 'в кафе' : 'наверху'}<div class="tiny muted">${fmtDate(o.readyAt)}, к ${fmtTime(o.readyAt)} · ${o.items.map(i => i.n).join(', ')}</div></div><span class="st ${STATUS[o.status].color}">${clientStatus(o)}</span></div>`).join('') : '<div class="empty">Вы ещё ничего не заказывали с этого устройства.</div>'}</div>
  </div></div>`;
}
